package RecyclerViewHelper

import android.app.AlertDialog
import android.app.DatePickerDialog
import android.content.Context
import android.icu.util.Calendar
import android.util.Log
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView
import fernando.morales.proyectoformativoo.R
import fernando.morales.proyectoformativoo.detalles_paciente
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import modelo.ClaseConexion
import modelo.PacienteDetalles
import modelo.Pacientes
import java.sql.ResultSet
import java.sql.SQLException


class Adaptador(var Datos: List<Pacientes>) : RecyclerView.Adapter<ViewHolder>() {

    fun ActualizarLista(nuevaLista: List<Pacientes>) {
        Datos = nuevaLista
        notifyDataSetChanged()
    }

    fun updateScreen(
        id_pacientes: Int,
        nuevaEdad: Int,
        nuevaEnfermedad: String,
        nuevaHabitacion: Int,
        nuevaCama: Int,
        nuevoIngreso: String
    )
    {
        val index = Datos.indexOfFirst { it.id_Pacientes == id_pacientes }
        if (index != -1) {
            Datos[index].paciente_Edad = nuevaEdad
            Datos[index].paciente_Enfermedad = nuevaEnfermedad
            Datos[index].numero_Habitacion = nuevaHabitacion
            Datos[index].cama = nuevaCama
            Datos[index].fecha_Ingreso = nuevoIngreso
            notifyItemChanged(index)
        }
    }

    fun deleteData(context: Context, id_paciente: Int, position: Int) {
        val dataList = Datos.toMutableList()
        dataList.removeAt(position)

        GlobalScope.launch(Dispatchers.IO) {
            val objConexion = ClaseConexion().cadenaConexion()
            if(objConexion != null) {
                try {
                    objConexion.autoCommit = false

                    val borrarAplicaciones = objConexion.prepareStatement("DELETE FROM aplicacion_Medicamentos WHERE id_Paciente = ?")!!
                    borrarAplicaciones.setInt(1, id_paciente)
                    val aplicacionesEliminadas = borrarAplicaciones.executeUpdate()
                    Log.d("deleteData", "Aplicacion de Medicamento eliminado: $aplicacionesEliminadas")

                    val borrarPaciente =
                        objConexion.prepareStatement("delete from Pacientes where id_Pacientes = ?")!!
                    borrarPaciente.setInt(1, id_paciente)
                    val pacienteEliminado = borrarPaciente.executeUpdate()
                    Log.d("deleteData", "Paciente eliminado: $pacienteEliminado")

                    objConexion.commit()
                    Log.d("deleteData", "Commit exitoso")

                    withContext(Dispatchers.Main) {
                        Datos = dataList.toList()
                        notifyItemRemoved(position)
                        notifyDataSetChanged()
                        Toast.makeText(
                            context,
                            "Paciente borrado correctamente",
                            Toast.LENGTH_SHORT
                        )
                            .show()
                    }
                } catch (e: SQLException) {
                    Log.e("deleteData", "Error al ejecutar operación SQL", e)
                    try {
                        objConexion.rollback()
                        Log.d("deleteData", "Rollback exitoso")
                    }catch (rollbackEx: SQLException){
                        Log.e("deleteData", "Error al hacer rollback", rollbackEx)
                    }
                    withContext(Dispatchers.Main) {
                        Toast.makeText(context, "Error al borrar paciente: ${e.message}", Toast.LENGTH_SHORT).show()
                    }
                }catch (e: Exception){
                    Log.e("deleteData", "Error inesperado", e)
                    withContext(Dispatchers.Main) {
                        Toast.makeText(context, "Error inesperado: ${e.message}", Toast.LENGTH_SHORT).show()
                    }
                } finally {
                    try {
                        objConexion.close()
                        Log.d("deleteData", "Conexión cerrada")
                    }catch (closeEx: SQLException){
                        Log.e("deleteData", "Error al cerrar la conexión", closeEx)
                    }
                }
            }else{
                withContext(Dispatchers.Main) {
                    Toast.makeText(context, "Error en la conexión, verifique conexion en la base de datos", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    fun updateData(context: Context, nuevaEdad: Int, nuevaEnfermedad: String, nuevaHabitacion: Int, nuevaCama: Int, nuevoIngreso: String, id_paciente: Int) {
        GlobalScope.launch(Dispatchers.IO) {
            val objConexion = ClaseConexion().cadenaConexion()
            if(objConexion != null) {
                try {
                    val actualizarPaciente =
                        objConexion.prepareStatement("update Pacientes set paciente_Edad = ?, paciente_Enfermaedad = ?, numero_Habitacion = ?, cama = ?, fecha_ingreso = ? where id_Pacientes = ?")!!
                    actualizarPaciente.setInt(1, nuevaEdad)
                    actualizarPaciente.setString(2, nuevaEnfermedad)
                    actualizarPaciente.setInt(3, nuevaHabitacion)
                    actualizarPaciente.setInt(4, nuevaCama)
                    actualizarPaciente.setString(5, nuevoIngreso)
                    actualizarPaciente.setInt(6, id_paciente)
                    actualizarPaciente.executeUpdate()

                    withContext(Dispatchers.Main) {
                        updateScreen(
                            id_paciente,
                            nuevaEdad,
                            nuevaEnfermedad,
                            nuevaHabitacion,
                            nuevaCama,
                            nuevoIngreso
                        )
                        Toast.makeText(
                            context,
                            "Se actualizaron los datos",
                            Toast.LENGTH_SHORT
                        ).show()

                    }
                } catch (e: Exception) {
                    withContext(Dispatchers.Main) {
                        Toast.makeText(context, "Error actualizar datos", Toast.LENGTH_SHORT)
                            .show()
                    }
                    e.printStackTrace()
                }finally {
                    objConexion.close()
                }
            }else{
                withContext(Dispatchers.Main) {
                    Toast.makeText(context, "Error en la conexión a la base de datos", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val vista =
            LayoutInflater.from(parent.context).inflate(R.layout.activity_card_paciente, parent, false)

        return ViewHolder(vista)
    }
    override fun getItemCount() = Datos.size

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = Datos[position]
        holder.txtNomPaciente.text = item.paciente_Nombre
        holder.txtApellidoPaciente.text = item.paciente_Apellido

        holder.btnEliminarPaciente.setOnClickListener {
            val context = holder.itemView.context

            val builder = androidx.appcompat.app.AlertDialog.Builder(context)
            builder.setTitle("Borrar")
            builder.setMessage("Estás segur@ de borrar este paciente?")

            builder.setPositiveButton("Si"){dialog, which ->
                deleteData(context, item.id_Pacientes, position)
            }

            builder.setNeutralButton("No"){dialog, which ->
                dialog.dismiss()
            }

            val dialog = builder.create()
            dialog.show()
        }

        holder.btnEditarPaciente.setOnClickListener {
            val context = holder.itemView.context

            val dialogView = LayoutInflater.from(context).inflate(R.layout.activity_editar_pacientes, null)
            val editEdad = dialogView.findViewById<EditText>(R.id.txtPEdadEd)
            val editEnfermedad = dialogView.findViewById<EditText>(R.id.txtPEnfermedadesEd)
            val editHabitacion = dialogView.findViewById<EditText>(R.id.txtNumHabitacionEd)
            val editCama = dialogView.findViewById<EditText>(R.id.txtPEdadEd)
            val editIngreso = dialogView.findViewById<EditText>(R.id.txtFechaEd)

            editIngreso.setOnClickListener {
                val calendario = Calendar.getInstance()
                val anio = calendario.get(Calendar.YEAR)
                val mes = calendario.get(Calendar.MONTH)
                val dia = calendario.get(Calendar.DAY_OF_MONTH)

                val datePickerDialog = DatePickerDialog(
                    context,
                    { view, anioSeleccionado, mesSeleccionado, diaSeleccionado ->
                        val calendarioSeleccionado = Calendar.getInstance()
                        calendarioSeleccionado.set(anioSeleccionado, mesSeleccionado, diaSeleccionado)
                        val fechaSeleccionada = "$diaSeleccionado/${mesSeleccionado + 1}/$anioSeleccionado"
                        editIngreso.setText(fechaSeleccionada)
                    },
                    anio, mes, dia
                )
                datePickerDialog.show()
            }

            editEdad.setHint(item.paciente_Edad.toString())
            editEnfermedad.setHint(item.paciente_Enfermedad)
            editHabitacion.setHint(item.numero_Habitacion.toString())
            editCama.setHint(item.cama.toString())
            editIngreso.setHint(item.fecha_Ingreso)

            val builder = AlertDialog.Builder(context)
            builder.setTitle("Actualizar Paciente")
            builder.setView(dialogView)
            builder.setPositiveButton("Guardar"){dialog, _ ->
                val nuevaEdad = editEdad.text.toString().toIntOrNull() ?: item.paciente_Edad
                val nuevaEnfermedad = editEnfermedad.text.toString()
                val nuevaHabitacion = editHabitacion.text.toString().toIntOrNull() ?: item.numero_Habitacion
                val nuevaCama = editCama.text.toString().toIntOrNull() ?: item.cama
                val nuevoIngreso = editIngreso.text.toString()

                updateData(context, nuevaEdad, nuevaEnfermedad, nuevaHabitacion, nuevaCama, nuevoIngreso, item.id_Pacientes)

                dialog.dismiss()
            }

            builder.setNegativeButton("Cancelar") {dialog, _ ->
                dialog.dismiss()
            }

            val alertDialog = builder.create()
            alertDialog.show()
        }

        holder.itemView.setOnClickListener {
            mostrarDialog(holder.itemView.context, item.id_Pacientes)
        }
    }

    private fun mostrarDialog(context: Context, idPaciente: Int) {
        val builder = AlertDialog.Builder(context)
        val dialogLayout =
            LayoutInflater.from(context).inflate(R.layout.activity_detalles_paciente, null)
        builder.setView(dialogLayout)

        val alertDialog = builder.create()

        GlobalScope.launch(Dispatchers.IO) {
            try {
                val pacienteDetalles = obtenerPacienteDet(idPaciente)

                withContext(Dispatchers.Main) {
                    dialogLayout.findViewById<TextView>(R.id.txtNombrePaciente1)?.text =
                        pacienteDetalles.paciente_Nombre
                    dialogLayout.findViewById<TextView>(R.id.txtApellidoPaciente1)?.text =
                        pacienteDetalles.paciente_Apellido
                    dialogLayout.findViewById<TextView>(R.id.txtPacienteEdad1)?.text =
                        pacienteDetalles.paciente_Edad.toString()
                    dialogLayout.findViewById<TextView>(R.id.txtPacienteEnfermedad1)?.text =
                        pacienteDetalles.paciente_Enfermedad
                    dialogLayout.findViewById<TextView>(R.id.txtNumeroHabitacion1)?.text =
                        pacienteDetalles.numero_Habitacion.toString()
                    dialogLayout.findViewById<TextView>(R.id.txtCama1)?.text =
                        pacienteDetalles.cama.toString()
                    dialogLayout.findViewById<TextView>(R.id.txtFecha1)?.text =
                        pacienteDetalles.fecha_Ingreso
                    dialogLayout.findViewById<TextView>(R.id.txtMed1)?.text =
                        pacienteDetalles.nombre_Medicamento
                    dialogLayout.findViewById<TextView>(R.id.txtHoraApli1)?.text =
                        pacienteDetalles.tiempo_Aplicacion

                    alertDialog.show()
                }

            } catch (e: Exception) {
                Log.e("AdaptadorPacientes", "Error al mostrar el dialog", e)
                withContext(Dispatchers.Main) {
                    Toast.makeText(
                        context,
                        "Debes asignar un medicamento para mostrar los datos",
                        Toast.LENGTH_LONG
                    ).show()
                }
            }
        }
    }

        private fun obtenerPacienteDet(idPaciente: Int): PacienteDetalles{
            val objConexion = ClaseConexion().cadenaConexion()
            if(objConexion == null){
                throw IllegalStateException("La conexión a la base de datos es null o no existe")
            }

            val statement = objConexion.createStatement()
            val query = """
            SELECT 
                p.paciente_Nombre AS nombre,
                p.paciente_Apellido AS apellido,
                p.paciente_Edad AS edad,
                p.paciente_Enfermedad AS enfermedad,
                p.numero_Habitacion AS habitacion,
                p.cama AS cama,
                p.fecha_Ingreso AS fecha_ingreso,
                m.nombre_Medicamento AS nombre_medicamento,
                am.tiempo_Aplicacion
            FROM 
                Aplicacion_Medicamentos am
            INNER JOIN 
                Pacientes p ON am.id_Paciente = p.id_Pacientes
            INNER JOIN 
                Medicamentos_Paciente m ON am.id_Medicamento = m.id_Medicamento
            WHERE p.id_Pacientes = $idPaciente
        """.trimIndent()

            val resultSet: ResultSet = statement.executeQuery(query)
            if(!resultSet.next()){
                throw IllegalStateException("NO se tienen detalles para el paciente")
            }

            val pacienteDetalles = PacienteDetalles(
                paciente_Nombre = resultSet.getString("paciente_Nombre"),
                paciente_Apellido = resultSet.getString("paciente_Apellido"),
                paciente_Edad = resultSet.getInt("paciente_Edad"),
                paciente_Enfermedad = resultSet.getString("paciente-Enfermedad"),
                numero_Habitacion = resultSet.getInt("numero_Habitacion"),
                cama = resultSet.getInt("cama"),
                fecha_Ingreso = resultSet.getString("fecha_Ingreso"),
                nombre_Medicamento = resultSet.getString("nombre_Medicamento"),
                tiempo_Aplicacion = resultSet.getString("tiempo_Aplicacion")
            )

            resultSet.close()
            statement.close()
            objConexion.close()

            return pacienteDetalles
        }
    }
