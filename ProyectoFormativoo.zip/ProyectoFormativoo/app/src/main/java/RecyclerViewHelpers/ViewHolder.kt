package RecyclerViewHelper

import android.view.View
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import fernando.morales.proyectoformativoo.R

class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
    val txtNomPaciente = view.findViewById<TextView>(R.id.txtNomPaciente)
    val txtApellidoPaciente = view.findViewById<TextView>(R.id.txtApellidoPaciente)
    val btnEliminarPaciente = view.findViewById<ImageView>(R.id.btnEliminarPaciente)
    val btnEditarPaciente = view.findViewById<ImageView>(R.id.btnEditarPaciente)
}
