package modelo

data class Pacientes(
    var id_Pacientes: Int,
    var paciente_Nombre: String,
    var paciente_Apellido: String,
    var paciente_Edad: Int,
    var paciente_Enfermedad: String,
    var numero_Habitacion: Int,
    var cama: Int,
    var fecha_Ingreso: String
)
