package modelo

data class PacienteDetalles(
    val paciente_Nombre: String,
    val paciente_Apellido: String,
    val paciente_Edad: Int,
    val paciente_Enfermedad: String,
    val numero_Habitacion: Int,
    val cama: Int,
    val fecha_Ingreso: String,
    val nombre_Medicamento: String,
    val tiempo_Aplicacion: String
)
