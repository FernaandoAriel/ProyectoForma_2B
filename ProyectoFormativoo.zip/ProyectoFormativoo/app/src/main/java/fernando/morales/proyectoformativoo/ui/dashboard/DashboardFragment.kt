package fernando.morales.proyectoformativoo.ui.dashboard

import RecyclerViewHelper.Adaptador
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import fernando.morales.proyectoformativoo.R
import fernando.morales.proyectoformativoo.databinding.FragmentDashboardBinding
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import modelo.ClaseConexion
import modelo.Pacientes

class DashboardFragment : Fragment() {

    private var _binding: FragmentDashboardBinding? = null

    // This property is only valid between onCreateView and
    // onDestroyView.
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        val dashboardViewModel =
            ViewModelProvider(this).get(DashboardViewModel::class.java)

        _binding = FragmentDashboardBinding.inflate(inflater, container, false)
        val root: View = binding.root

        val rcvPacientes = root.findViewById<RecyclerView>(R.id.rcvListaPacientes)

        rcvPacientes.layoutManager = LinearLayoutManager(context)

        fun obtenerPacientes(): List<Pacientes> {
            val listaPacientes = mutableListOf<Pacientes>()
            val objConexion = ClaseConexion().cadenaConexion()
            objConexion?.use { conn ->
                val statement = conn.createStatement()
                val resultSet = statement?.executeQuery("SELECT * FROM Pacientes")!!
                while (resultSet.next()) {
                    val id_paciente = resultSet.getInt("id_Pacientes")
                    val nombre = resultSet.getString("paciente_Nombre")
                    val apellido = resultSet.getString("paciente_Apellido")
                    val edad = resultSet.getInt("paciente_Edad")
                    val enfermedad = resultSet.getString("paciente_Enfermaedad")
                    val habitacion = resultSet.getInt("numero_Habitacion")
                    val cama = resultSet.getInt("cama")
                    val fecha = resultSet.getDate("fecha_Ingreso")

                    val valoresJuntos = Pacientes(id_paciente, nombre, apellido, edad, enfermedad, habitacion, cama, fecha.toString()
                    )

                    listaPacientes.add(valoresJuntos)
                }
            }

            return listaPacientes

        }

        CoroutineScope(Dispatchers.IO).launch {
            val nuevosPacientes = obtenerPacientes()
            withContext(Dispatchers.IO){
                (rcvPacientes.adapter as? Adaptador)?.ActualizarLista(nuevosPacientes)
            }
        }

        CoroutineScope(Dispatchers.IO).launch {
            val pacientesDB = obtenerPacientes()
            withContext(Dispatchers.Main){
                val adapter = Adaptador(pacientesDB)
                rcvPacientes.adapter = adapter
            }
        }


        dashboardViewModel.text.observe(viewLifecycleOwner) {

        }
        return root
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}