package fernando.morales.proyectoformativoo.ui.notifications

import android.app.AlertDialog
import android.app.DatePickerDialog
import android.content.Intent
import android.icu.util.Calendar
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import fernando.morales.proyectoformativoo.R
import fernando.morales.proyectoformativoo.agregar_medicamentos
import fernando.morales.proyectoformativoo.databinding.FragmentNotificationsBinding
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import modelo.ClaseConexion

class NotificationsFragment : Fragment() {

    private var _binding: FragmentNotificationsBinding? = null

    // This property is only valid between onCreateView and
    // onDestroyView.
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        val notificationsViewModel =
            ViewModelProvider(this).get(NotificationsViewModel::class.java)

        _binding = FragmentNotificationsBinding.inflate(inflater, container, false)
        val root: View = binding.root

        val btnMedicamentos = root.findViewById<Button>(R.id.btnMedicamentos)
        btnMedicamentos.setOnClickListener {
            val pantallaNuevosMedicamentos = Intent(context, agregar_medicamentos::class.java)
            startActivity(pantallaNuevosMedicamentos)
        }

        val txtNombrePacientes = root.findViewById<EditText>(R.id.txtNombrePaciente)
        val txtApellidosPacientes = root.findViewById<EditText>(R.id.txtApellidoPaciente)
        val txtEdadPacientes = root.findViewById<EditText>(R.id.txtEdadPaciente)
        val txtEnfermedadPacientes = root.findViewById<EditText>(R.id.txtEnfermedadPac)
        val txtNumeroHabitacion = root.findViewById<EditText>(R.id.txtNumeroHab)
        val txtNumeroCama = root.findViewById<EditText>(R.id.txtCamaPaciente)
        val txtFechaIngreso = root.findViewById<EditText>(R.id.txtFechaIngresoP)

        txtFechaIngreso.setOnClickListener {
            val calendario = Calendar.getInstance()
            val anio = calendario.get(Calendar.YEAR)
            val mes = calendario.get(Calendar.MONTH)
            val dia = calendario.get(Calendar.DAY_OF_MONTH)

            val datePickerDialog = DatePickerDialog(
                requireContext(),
                { view, anioSeleccionado, mesSeleccionado, diaSeleccionado ->
                    val calendarioSeleccionado = Calendar.getInstance()
                    calendarioSeleccionado.set(anioSeleccionado, mesSeleccionado, diaSeleccionado)
                    val fechaSeleccionada = "$diaSeleccionado/${mesSeleccionado + 1}/$anioSeleccionado"
                    txtFechaIngreso.setText(fechaSeleccionada)
                },
                anio, mes, dia
            )

            datePickerDialog.show()
        }

        val btnEnviarPaciente = root.findViewById<Button>(R.id.btnEnviarPaciente)

        btnEnviarPaciente.setOnClickListener {

            val nombre = txtNombrePacientes.text.toString()
            val apellido = txtApellidosPacientes.text.toString()
            val edad = txtEdadPacientes.text.toString()
            val enfermedad = txtEnfermedadPacientes.text.toString()
            val habitacion = txtNumeroHabitacion.text.toString()
            val cama = txtNumeroCama.text.toString()
            val ingreso = txtFechaIngreso.text.toString()

            if(nombre.isEmpty() || apellido.isEmpty() || edad.isEmpty() || enfermedad.isEmpty() || habitacion.isEmpty() || cama.isEmpty() || ingreso.isEmpty()){
                Toast.makeText(requireActivity(),
                    "Error, para enviar el registro debes llenar todas las casillas.",
                    Toast.LENGTH_SHORT
                ).show()
            }else {
                CoroutineScope(Dispatchers.IO).launch {
                    val objConexion = ClaseConexion().cadenaConexion()
                    val addPaciente =
                        objConexion?.prepareStatement("INSERT INTO Pacientes(pacientes_Nombre, paciente_Apellido, paciente_Edad, paciente_Enfermaedad, numero_Habitacion, cama, fecha_Ingreso) VALUES (?, ?, ?, ?, ?, ?, ?)")!!
                    addPaciente.setString(1, txtNombrePacientes.text.toString())
                    addPaciente.setString(2, txtApellidosPacientes.text.toString())
                    addPaciente.setInt(3, txtEdadPacientes.text.toString().toInt())
                    addPaciente.setString(4, txtEnfermedadPacientes.text.toString())
                    addPaciente.setInt(5, txtNumeroHabitacion.text.toString().toInt())
                    addPaciente.setInt(6, txtNumeroCama.text.toString().toInt())
                    addPaciente.setString(7, txtFechaIngreso.text.toString())
                    addPaciente.executeQuery()

                    withContext(Dispatchers.Main) {
                        AlertDialog.Builder(requireContext())
                            .setTitle("Registro de paciente exitoso!")
                            .setMessage("Ahora debes asignar un medicamento!")
                            .setPositiveButton("Aceptar", null)
                            .show()
                        txtNombrePacientes.setText("")
                        txtApellidosPacientes.setText("")
                        txtEdadPacientes.setText("")
                        txtEnfermedadPacientes.setText("")
                        txtNumeroHabitacion.setText("")
                        txtNumeroCama.setText("")
                        txtFechaIngreso.setText("")
                    }
                }
            }
        }

        notificationsViewModel.text.observe(viewLifecycleOwner) {

        }
        return root
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}