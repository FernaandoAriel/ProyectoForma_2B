package fernando.morales.proyectoformativoo

import android.content.Intent
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.Spinner
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import modelo.ClaseConexion

class seleccionar_medicamentos : AppCompatActivity() {

    private lateinit var txtAsignarHoraM: EditText
    private lateinit var spPaciente: Spinner
    private lateinit var spMedicamentos: Spinner
    private lateinit var btnAplicar: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_seleccionar_medicamentos)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        val btnVolver = findViewById<ImageView>(R.id.btnVolver)
        btnVolver.setOnClickListener {
            val pantallaNMedicamento = Intent(this, agregar_medicamentos::class.java)
            startActivity(pantallaNMedicamento)
        }

        txtAsignarHoraM = findViewById(R.id.txtAsignarHoraM)
        spPaciente = findViewById(R.id.spPaciente)
        spMedicamentos = findViewById(R.id.spMedicamentos)
        btnAplicar= findViewById(R.id.btnAplicar)

        loadPaciente()
        loadMedicamento()

        btnAplicar.setOnClickListener {
            val AsignarHoraM = txtAsignarHoraM.text.toString()
            val pacienteSelec = spPaciente.selectedItem.toString()
            val medicamentoSelec = spMedicamentos.selectedItem.toString()

            CoroutineScope(Dispatchers.Main).launch {
                val idPaciente = getIdPacientes(pacienteSelec)
                val idMedicamento = getIdMedicamento(medicamentoSelec)

                if (idPaciente != null && idMedicamento != null) {
                    val result =
                        saveAplicacionMedicamento(AsignarHoraM, idPaciente, idMedicamento)
                    if (result) {
                        Toast.makeText(
                            this@seleccionar_medicamentos,
                            "Asignación guardada correctamente",
                            Toast.LENGTH_SHORT
                        ).show()

                        txtAsignarHoraM.setText("")
                    } else {
                        Toast.makeText(
                            this@seleccionar_medicamentos,
                            "Error al guardar la asignación",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                } else {
                    Toast.makeText(
                        this@seleccionar_medicamentos,
                        "Error: No se pudo obtener los IDs",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }
        }
    }

    private fun loadPaciente() {
        CoroutineScope(Dispatchers.IO).launch {
            val pacientes = PacientesDeDB()
            withContext(Dispatchers.Main) {
                val adapter = ArrayAdapter(
                    this@seleccionar_medicamentos,
                    android.R.layout.simple_spinner_item,
                    pacientes
                )
                adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
                spPaciente.adapter = adapter
            }
        }
    }

    private fun loadMedicamento() {
        CoroutineScope(Dispatchers.IO).launch {
            val medicamento = MedicamentosDeDB()
            withContext(Dispatchers.Main) {
                val adapter = ArrayAdapter(
                    this@seleccionar_medicamentos,
                            android.R.layout.simple_spinner_item,
                            medicamento
                )
                adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
                spMedicamentos.adapter = adapter
            }
        }
    }
}

private suspend fun MedicamentosDeDB(): List<String> = withContext(Dispatchers.IO) {
    val medicamentos = mutableListOf<String>()
    val querY = "SELECT nombre_Medicamento FROM Medicamentos_Paciente"
    val objConexion = ClaseConexion().cadenaConexion()

    objConexion?.let {
        try {
            val statement = it.createStatement()
            val resultSet = statement.executeQuery(querY)

            while (resultSet.next()) {
                val nombre_Medicamento = resultSet.getString("nombre_Medicamento")
                medicamentos.add(nombre_Medicamento)
            }

            resultSet.close()
            statement.close()
        } catch (e: Exception) {
            e.printStackTrace()
        } finally {
            it.close()
        }
    }

    medicamentos
}

private suspend fun PacientesDeDB(): List<String> = withContext(Dispatchers.IO) {
    val pacientes = mutableListOf<String>()
    val queryS = "SELECT paciente_Nombre, paciente_Apellido FROM Pacientes"
    val objConexion = ClaseConexion().cadenaConexion()
    objConexion?.let {
        try {
            val statement = it.createStatement()
            val resultSet = statement.executeQuery(queryS)

            while (resultSet.next()) {
                val nombre = resultSet.getString("paciente_Nombre")
                val apellido = resultSet.getString("paciente_Apellido")
                pacientes.add("$nombre $apellido")
            }

            resultSet.close()
            statement.close()
        } catch (e: Exception) {
            e.printStackTrace()
        } finally {
            it.close()
        }
    }

    pacientes
}

private suspend fun getIdPacientes(nombreCompleto: String): Int? =
    withContext(Dispatchers.IO) {
        val query =
            "SELECT id_Pacientes FROM Pacientes WHERE (paciente_Nombre || ' ' || paciente_Apellido) =  ?"
        val objConexion = ClaseConexion().cadenaConexion()

        objConexion?.let {
            try {
                val statement = it.prepareStatement(query)
                statement.setString(1, nombreCompleto)
                val resultSet = statement.executeQuery()

                if (resultSet.next()) {
                    val idPaciente = resultSet.getInt("id_Pacientes")
                    resultSet.close()
                    return@withContext idPaciente
                }
            } catch (e: Exception) {
                e.printStackTrace()
            } finally {
                it.close()
            }

        }
        null
    }

    private suspend fun getIdMedicamento(nombreMedicamento: String): Int? =
    withContext(Dispatchers.IO) {
        val querYS = "SELECT id_Medicamento FROM Medicamentos WHERE nombre_Medicamento = ?"
        val objConexion = ClaseConexion().cadenaConexion()

        objConexion?.let {
            try {
                val statement = it.prepareStatement(querYS)
                statement.setString(1, nombreMedicamento)
                val resultSet = statement.executeQuery()

                if (resultSet.next()) {
                    val idMedicamento = resultSet.getInt("id_Medicamento")
                    resultSet.close()
                    return@withContext idMedicamento
                }
            } catch (e: Exception) {
                e.printStackTrace()
            } finally {
                it.close()
            }
        }

        null
    }

private suspend fun saveAplicacionMedicamento(
    AsignarHorasM: String,
    idPacientes: Int,
    idMedicamentos: Int
): Boolean = withContext(Dispatchers.IO) {
    val querys =
        "INSERT INTO aplicaciobn_Medicamentos (tiempo_Aplicacion, id_Paciente, id_Medicamento) VALUES (?, ?, ?)"
    val objConexion = ClaseConexion().cadenaConexion()

    objConexion?.let {
        try {
            val statement = it.prepareStatement(querys)
            statement.setString(1, AsignarHorasM)
            statement.setInt(2, idPacientes)
            statement.setInt(3, idMedicamentos)
            statement.executeUpdate()
            statement.close()
            it.close()
            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        } finally {
            it.close()
        }
    } ?: false
}